/** @jsx React.DOM */

var React = require("react");

var CompanyLogo = React.createClass({
  render: function(){
    return (<img src="http://example.com/logo.png" />);
  }
});

module.exports = CompanyLogo;
module.exports = {
  SAVE_SURVEY:   "save",
  DELETE_SURVEY: "delete",
  RECORD_SURVEY: "record"
}

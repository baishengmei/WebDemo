/**
 * Created by baishengmei on 2016/4/12.
 */
//var btn1, timeBtn;
window.onload = function(){
    timeCompute();
}



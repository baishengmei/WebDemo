/**
 * Created by baishengmei on 2016/4/13.
 */
dealCards1();
var fetchCard = function () {
    //randPoint

}